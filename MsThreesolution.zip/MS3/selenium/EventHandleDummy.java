package Utils;

import org.openqa.selenium.support.events.WebDriverListener;

public class EventHandler implements WebDriverListener {

}

