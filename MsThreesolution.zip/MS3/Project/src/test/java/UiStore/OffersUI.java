package UiStore;

import org.openqa.selenium.By;

public class OffersUI {
    
    public static By Showmore = By.xpath("//*[@id=\"product-facet\"]/div[14]/div[9]/div/div[2]/div/div/button");
    public static By Offers = By.xpath("//a[contains(text(),'Offers')]");
    public static By Brands = By.xpath("//span[contains(text(),'Paw Patrol')]");
    public static By ProductName = By.xpath("//a[contains(text(),\"Paw Patrol Total Team Rescues: Chase's Team Police\")]");
   
   
}
